<?php
_error("INSTALLATION ERROR", '
<p class="text-center">Your PHP installation appears to be missing the <strong>'. $ext .'</strong> function which is required by PHPTRAVELS.</p>
<small>Back to your server admin or hosting provider to enable it for you</small><br>
<small>or contact <br>info@phptravels.com</small>
');
?>