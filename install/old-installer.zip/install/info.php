<?php phpinfo(); ?>
<?php phpinfo(INFO_MODULES); ?>

